

#the following program is designed to take the data from the input the user enters into the krun document and then do the followering
#1 turn those that data into unicode
#2 turn that data into words based on a memory tobwords system, eg 87 leg 
#3 display those words as a sententence eg the hreat lef cated the dog house

#the main purpose of doing the above is to allow for remembering text to beco"e easier

import os
#imports needed to take data from other file

#The program extracts the data from 'krun'
f = open("krun","r")

inputUser = f.read()
#sets data to var inputUser

inputUser = str(inputUser)

inputUser = inputUser + "\nend of program"

inputUser = inputUser.replace("®","¿")


inputUser = inputUser.replace("¡","¿")


inputUser = inputUser.replace("©","¿")


inputUser = inputUser.replace("\n","®")


inputUser = inputUser.replace(" ","©")


inputUser = inputUser.replace("	","¡")




#ensures that the input is read as  string

g = open("charCon","r")
#sets g to charCon
#charCon is the document that has the list of what words need to chnge the unicode values

conList = g.read()
#sets var conList to g

conList = str(conList)
#ensures that data is read as a string

uniWords = []
#is used to store all unicode characters in the word


charKrun = " "
#this var is used to store a single character of input user var as to convert it to the unicode word representation

secCharKrun = " "
#storing single charactwr from conList

uniLen = len(inputUser)
#sets to lenth of userInout needed for the loop

conLen = len(conList)
#sets lenth of conList to new vr conLen
conLen = int(conLen)

count = 0
#used for while loop

secCount = 0
#used for while loop inside the while loop

secCount = int(secCount)
#converts var to int

#print (conList)
mess = (inputUser[0])
while count < uniLen:
# print ("hello bebe")
#while loop to clnvert each character of the user input and save it in the uiWors list
 count = count + 1
 if count < uniLen:
  countMinus = count - 1
  charKrun = (inputUser[countMinus])
 # conLen = len(conList)
  while secCount < conLen:
   secCount = secCount + 1
   if secCount < conLen:
    secCharKrun = (conList[secCount])
    if secCharKrun == "@":
#     b = secCount + 1
#     a = (conList[b])
 #    print (a)
     secCount = secCount + 1
     secCharKrun = (conList[secCount])
     if secCharKrun == charKrun:
       charKrun = ""
       thirdCount = secCount
       while secCharKrun != "*":
        thirdCount = thirdCount + 1
        secCharKrun = (conList[thirdCount])
        charKrun = charKrun + secCharKrun
       uniWords.append(charKrun)
  #   secCount = secCount - 1
 secCount = 0

#add comments to every one of the while loop

#if not in list print ririririruririri




def conUni():
#def my_function():
 print (inputUser)
 print ("cat woman")

 print (uniWords)
 
 inTig = inputUser + "\n" + "\n"

conUni()
print (mess)

global tigerCount

tigerCount = 0

global tigerMan

tigerMan = " "

print (inputUser)

def tigerFunc():
 inTig = inputUser + "®" + "®"
 print ("lion goldfish")
 print (inTig)
 global tigerCount
 sizeTiger = len(inTig)
 global tigerMan
 tigerMan = "	"
 if sizeTiger > tigerCount:
  while inTig[tigerCount] != "®":
   tigerMan = tigerMan + inTig[tigerCount]
   tigerCount += 1

final = " "

tigerFunc()


print (tigerMan)

print ("tigerMan")



print (final)

print ("final")



print (tigerMan)
#if len is greater than five

amber = len (uniWords)

zelda = 0

luke = zelda + 5

#test looo with diffrent inputs
while luke < amber:

	final = final + "the "

	final = final + (uniWords[zelda])

	if (uniWords[zelda]) == "doss*":
	 print ("---")
	 final = final + "\n"
	 final = final + "\n"
	 final = final + "\n"
	 final = final + "\n"
	 conUni()
	 final += "$%%%" 

	zelda += 1

	final = final + " in " + (uniWords[zelda])

	if (uniWords[zelda]) == "doss*":
	 print ("---")
	 final = final + "\n"
	 final = final + "\n"
	 final = final + "\n"
	 final = final + "\n"
#	 print (uniWords[zelda])
	 

	 final += "®" 
	 final += "$%%%" 

	zelda += 1


	final = final + " will " + (uniWords[zelda]) + " for the "


	if (uniWords[zelda]) == "doss*":
	 print ("---")
	 final = final + "\n" 
	 final = final + "\n"
	 final = final + "\n"
	 final = final + "\n"
	 tigerFunc()
	 final += "®" 
	 final += "$%%%" 


	print (uniWords[zelda])


#	 print (uniWords[zelda])


	zelda += 1


	final = final + (uniWords[zelda]) + " in "

	print (uniWords[zelda])

	if (uniWords[zelda]) == "doss*":
	 print ("---")
	 final = final + "\n" 
	 final = final + "\n"
	 final = final + "\n"
	 final = final + "\n"

	 tigerFunc()
	 final += "®" 
	 final += "$%%%%" 


#	 print (uniWords[zelda])


	zelda += 1

	final = final + (uniWords[zelda]) + ". However, "

	print (uniWords[zelda])
	print ("$$$$")
	cooler = (uniWords[zelda])
	print (cooler)
	if cooler == "doss*":
	 print ("jacket")
	 print ("---")
	 final = final + "\n" 
	 final = final + "\n"
	 final = final + "\n"
	 final = final + "\n"

	 tigerFunc()
	 final += "$%%%" 

	 print (tigerMan)
	 print ("tigerMan")

#	 print (uniWords[zelda])



	zelda += 1

	luke = zelda + 5


print (final)


print (inputUser)
print (len(inputUser))


print (len(final))

##adds these to var to arrays

finVar = final

bigFinVar = len(finVar) - 2

inVar = inputUser

bigInVar = len(inputUser)- 2

krunFin = ""

krunList = ""

krunIn = ""

finArr = []

inArr = []

# two arrays to store all values until the end to add to.final doument

print ("money for moneyμdjdjdhdjskfbsnfndb")

print (finVar)


print (inVar)

lastKrun = 0
endLoop = 0
while endLoop < 3:
	print (endLoop)
	print ("lastKrun")
	print (lastKrun)


	print ("")
	print ("")
	print ("")
	print ("")
	print ("")


	print (bigFinVar)
	
	endLoop = 0
	while endLoop == 0:
	 krunFin = finVar[lastKrun]
	 krunList = krunList + finVar[lastKrun]
	 lastKrun = lastKrun + 1
	 if lastKrun > bigFinVar:
	  endLoop = 5
	 if krunFin == "$":
	  endLoop = endLoop + 1
	  


	finArr.append(krunList)
	krunList = ""
	if lastKrun > bigFinVar:
	 endLoop = 5

###


print ("list")



print (finArr)

print ("caat")

print (len(finArr))

print ("")
print ("°°°°°°°°")
print ("")
print ("")




### j   jdjfjdejdndjdjdj  ####
#inVar = inputUser
#finVar = final




lastKrun = 0
endLoop = 0
while endLoop < 3:
	print (endLoop)
	print ("lastKrun")
	print (lastKrun)


	print ("")
	print ("")
	print ("")
	print ("")
	print ("")


	print (bigInVar)
	
	endLoop = 0
	while endLoop == 0:
	 krunIn = inVar[lastKrun]
	 krunList = krunList + inVar[lastKrun]
	 lastKrun = lastKrun + 1
	 if lastKrun > bigInVar:
	  endLoop = 5
	 if krunIn == "®":
	  endLoop = endLoop + 1
	  


	inArr.append(krunList)
	krunList = ""
	if lastKrun > bigInVar:
	 endLoop = 5
 

print ("")
print ("")
print ("")

print (inArr)


print (len(inArr))

print ("")
print ("°°°°°°°°")
print ("")
print ("")



##########$$##

bigArr = len(finArr)
print ("sexy")
print (inArr)
print (bigArr)
print (finArr)
endProd = ""

endCount = 0

while endCount <  bigArr:
 print (endCount)
 print (inArr[endCount])
 print (finArr[endCount])
 endProd = endProd + inArr[endCount] + finArr[endCount] 
 endCount = endCount + 1

print ("$-$     djrjdnfn... dinosaur")

print (endProd)
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################
##############################






final = ("finalUnicode")
#this is the name of the file in which he new data will be sent to

cwd = os.getcwd()
#this the varible 'cwd' to the current working directory
#this is used to assist in the file parth below


full = (cwd + "/" + final)
#the varible ful is set the current working directory plus the file name 
#this var will be used to write the data to the file nam

f = open (full,"a")
#opens the parth of varible 'full'

os.remove(full)
#removes the document if it exists (therefore deleting all content inside)

f = open (full,"a")
#opens file parth again and therefore creates the document

f.write (endProd)
#ites contents of 'endProd' to the document
print (endProd)

###############

print ("\n" + "\n" + "The program was a sucess")

print ("\n" + "Please open the 'finalUnicode' document to see the results")
#The above is to onform the user that the program has been compled 

print ("\n" + "\n" + "\n" + "\n" + "\n")
