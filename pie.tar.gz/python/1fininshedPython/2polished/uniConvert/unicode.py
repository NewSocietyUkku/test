import os

import random



#This program requires that the user has a basic understanding of unicode.

#This program creates text that the user is expected to then place in a read aloud program. This program does not by it's self read the text aloud.

#This program reads line by line normaly and then reads the unicode version of the line. This allows for programs to be easier understood. For example, system.out.print("a"), will be read in the unicode format and this will allow the user to be hear where the other characters {.(")} are. 

##Base 10 unicode number system is used as opposed to base 16 unicode number system. So 'a=97' not 'a=61'.

##In order to help process the unicode better the unicode numbers are converted to words using a standard memory technique. If a word startsd with D, then it is repersented with one. if the word starts with c/k, then it is two. And so on. Please see the words below to see the numbers they repersent. For example 557 will be Fig, fig, goose.

##The way these are shown in practice is by a noun, verb and noun. The verb is used to show the previose number. If the user misheard the number, they can then clarify using the verb. For example, in '1234567' the fifth number would be shown as the fig kisses the fig (Notice how the 'f' words are repeated twice. Also notice that the previose 2 is repersented by the K.).

##The term 'What?' is used to seperate unicode characters from each other. For example 105 What? 107

##The words which are used are chosen at random. Below are a list of words that will be chosen at random to repersent a number

one = ["dog","dad","doll","dinosaur","disk","dove","duck","diamond","dust","death","ice","drain","dolphin","dinner night","dress","dragon","door","daffodil"]

oneVerb = ["drilled into","dropped","danced with","dreamed of","discovered","defended","declined to work with","drinked with","delighted","drooled over","dressed","undressed","delivered","defeated","defined","donated to","documented the","doubted","departed from","dined with","delt with","dominated","domesticated"]

two = ["kid","car","cat","can","kite","coat","clone","carnivore","clock","computer","carpet"]

twoVerb = ["kissed","killed","called","caught","kicked","coughed over","climed over","canceled","cared about","celebrated","calmed the","caught","camped with","cursed","carried","chatted with","chased","catered for","carried","captivated","created","controlled"]

three = ["rat","water","wall","wine","wieght","rice","writer","waiter","worm","rent","rose"]

threeVerb = ["washed","wandered about","warmed up","rested","wasted","wrecked","walked","rolled over","rided with","ripped open","released the","raped","watched over","raced with","reflected about","ran with","rode","raised","reached out for","rambled about","wrestled"]

four = ["tap","pet","tree","troll","pig","tick","tank","pipe","Pope","tape"]

fourVerb = ["talked to","traped","popped","trained","tampered with","tackled","thanked","tosed out","targeted","tested","tagged along with","touched","talked to","traveled with","tried out","taught","played with","pulled out of","pushed out","pacified","painted","promoted","paralysed","pampered","pardoned","paraded","picked","pressented","Perserved","persuaded","parted with","payed","praised"]

five = ["fig","van","flower","farther","villain","vanilla icecream","viking","frog","food","vacation"]

fiveVerb = ["verified","vibrated","varnished","vacuumed","ventilated","visited","visualised","fascinated","fancied","faded into","fought","feeded","frightened","fell into","finalised","fucked","fingered","forgot about","prayed for","felt","feared for","fetched","fabricated","fired","filtered","freed"]

six = ["mother","mouse","net","moon","knight","nieghbore","nightmare","monster","knife","motor bike","joker","money"]

sixVerb = ["neglected","negotiated with","nibbled on","naturalised","nominated","needed","noticed","networked with","noticed","nailed","joined","justified","jerked off","jumped over","married","motivated","manipulated","melted","manufactured","maintained","mimiced","mislead","mocked","modified"]

seven = ["gas","Yankee","Yeti","goddess","gangster","girl","gold","glitter","ghost","yeast","yogurt"]

sevenVerb = ["yelled at","gambled with","Googled","gave up on","giggled with","generated","gained","grew","guessed of","guarded","glared at","graded","glued","greeted","grated","ghosted","greased","griped","guaranteed",]

eight = ["lamp","hippo","hat","Hulk","healer","lion","hiker","Lego","lgiht"]

eightVerb = ["hugged","hated","hoped for","helped","hanged","hacked into","hammered","harassed","harvesdted","headed to","harmed","haunted","hijacked","hampered","hinted at","listened to","left","licked","loved","laughed at","liked","learned from","left","lost","liberated","located","looked for","locked in","loosened","lied to","lived with","lubricated","lifted up","let out","lay down","lavished","liberalised"]

nine = ["bull","bread","buck","chain","chip","ball","bath"]

nineVerb = ["baked","checked","booked","bited into","billed","balanced","believed in","blessed","barked at","bargained with","bend over for","begged","breather over","behaved well with","bypassed","billed","bought","chirped with","chased","changed","choked on","chatted with","chose","charmed","branded","begged"]

zero = ["zebra","zipper","zombie","zoom","zink","swamp","salt","sushi","snake","storm","stalker","shoe","sand","sadness","sacrifice","scale","saffron","scandal","shop"]

zeroVerb = ["saved","sold","selected","stored","shined over","stole","stained","stuck to","satisfied","sang with","served","swayed with","stared at","smiled at","sailed with","scanned","shrunk","snored with","searched for","stoped","stung","spoiled","shot","shopped with","sleeped with","sold","surpassed","swinged with","shared with","sneezed over","studied","supplied","strengthened"]


f = open ("krun","r")

linesList = f.readlines()

#linesList is set to being equal to the contents of krun file

#linesList isn't an array, but each line is displayed with /n






#this is th end product that needs to be read out to the user

endProd = ""

skipLine = 0

space =" : "

count = 0
#is used to act as a counter for the while loop to add one each t,e

verbKrun = ""



sizeLines = len(linesList)

#this sets sizeLines to the number of lines in the document



verbSelectFinal = ("because of")
verbSelect1st = ""


verbSelect2nd = ""



verbSelect3rd = ""



while count < sizeLines:

 lineRecorder = (linesList[count])
 #it is reading lineRecorder as a list
 endProd = endProd + space + "\n" + lineRecorder + lineRecorder + lineRecorder
 #adds to  the final product the lime three times
 #this results in each line being print out three times to ensure that the users have time listen to it clearly

 removeComment = 0
 whileRemove = 0
 removeCommentPlus = removeComment + 1
 if removeCommentPlus < len(lineRecorder):
  if lineRecorder[removeComment] == " ":
   whileRemove = 1
  if lineRecorder[removeComment] == "	":
   whileRemove = 1
  #the above is to ensure that all spaces are tabs are excluded from the tester
  #the test is meant to remove comments (which start with #). The '#' of comments can appear after a tab or space
  while whileRemove == 1:
   removeComment += 1
   removeCommentPlus = removeComment + 1
   if removeCommentPlus < len(lineRecorder):
    whileRemove = 1
   else:
    whileRemove = 0
   
   if lineRecorder[removeComment] != " ":
    whileRemove = 0
   if lineRecorder[removeComment] == "	":
    whileRemoe = 1
   #the above to entended for if more than one spacr are tab is used and if a mix of the two are used before thebpotential '#' for the comment

 if lineRecorder[removeComment] == "#":
  skipLine = 1
 #this is the end product that needs to be read out to the user
 convertedToUnicode = [ord(char) for char in lineRecorder]
 #is used to convert the character to unicode

#now the program needs to start dealing with individual chars
 if skipLine == 0:
 #checker, only proceedes if the line isn't a comment
	 convertedToUnicode = str(convertedToUnicode)
#ensures that the program reads the line as a string
	 sizeUnicode = len(convertedToUnicode)
#records the lentn if line, used for while loop
	 secondCount = 0
#user for while loop below
	 sizeUnicodeMinus = sizeUnicode 
#records another var being equal to below for usr in loop below

#the loop below converts each char to unicode form

	 while secondCount<sizeUnicodeMinus:
	  if convertedToUnicode[secondCount] == "1":
#below are the verbs that record thcurrent value as to be recorded  later, so that is the user does not hear a value, they can theb listen to the vrbs
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 1



	   firstSelect = (random.choice(one))
	   secondSelect = (random.choice(one))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."




	  if convertedToUnicode[secondCount] == "2":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 2


	   
	   firstSelect = (random.choice(two))
	   secondSelect = (random.choice(two))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."




	  if convertedToUnicode[secondCount] == "3":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 3
	   
	   firstSelect = (random.choice(three))
	   secondSelect = (random.choice(three))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."




	  if convertedToUnicode[secondCount] == "4":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 4
	  

	   firstSelect = (random.choice(four))
	   secondSelect = (random.choice(four))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."


	  if convertedToUnicode[secondCount] == "5":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 5
	   
	   firstSelect = (random.choice(five))
	   secondSelect = (random.choice(five))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."
	   balls = secondCount + 1
	   bats = secondCount + 2


	  if convertedToUnicode[secondCount] == "6":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 6
	   
	   firstSelect = (random.choice(six))
	   secondSelect = (random.choice(six))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."


	  if convertedToUnicode[secondCount] == "7":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 7
	   
	   firstSelect = (random.choice(seven))
	   secondSelect = (random.choice(seven))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."



	  if convertedToUnicode[secondCount] == "8":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 8
	  
	   firstSelect = (random.choice(eight))
	   secondSelect = (random.choice(eight))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."

	  if convertedToUnicode[secondCount] == "9":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 9
	   
	   firstSelect = (random.choice(nine))
	   secondSelect = (random.choice(nine))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."



	  if convertedToUnicode[secondCount] == "0":
	   verbSelect1st = verbSelect2nd
	   verbSelect2nd = verbSelect3rd
	   verbSelect3rd = 0
	   
	   firstSelect = (random.choice(zero))
	   secondSelect = (random.choice(zero))
	   verbKrun = verbKrun + " The " + firstSelect + " " + verbSelectFinal + " " + "the" + " " + secondSelect + "."

	  if convertedToUnicode[secondCount] == ",":
	   verbKrun = verbKrun + " What? "




	  if verbSelect1st == 1:
	   verbSelectFinal = (random.choice(oneVerb))
	  if verbSelect1st == 2:
	   verbSelectFinal = (random.choice(twoVerb))
	  if verbSelect1st == 3:
	   verbSelectFinal = (random.choice(threeVerb))
	  if verbSelect1st == 4:
	   verbSelectFinal = (random.choice(fourVerb))
	  if verbSelect1st == 5:
	   verbSelectFinal = (random.choice(fiveVerb))
	  if verbSelect1st == 6:
	   verbSelectFinal = (random.choice(sixVerb))
	  if verbSelect1st == 7:
	   verbSelectFinal = (random.choice(sevenVerb))
	  if verbSelect1st == 8:
	   verbSelectFinal = (random.choice(eightVerb))
	  if verbSelect1st == 9:
	   verbSelectFinal = (random.choice(nineVerb))
	  if verbSelect1st == 0:
	   verbSelectFinal = (random.choice(zeroVerb))
	  

	  secondCount += 1
	  
	  
	 endProd = endProd + space + verbKrun + "\n" + "\n" + "I really need a holiday. Will you give me one? I want to travel the world." + "\n" + "\n" 
#then the unicode is added onto 'end Product. At the end the phrase "I really need a holiday" iadded so the user knows that the one line is finished aand that they will be moving onto the next line
 verbKrun = ""
#############################################33
 skipLine = 0
 count += 1








final = ("finalUnicode")
#this is the name of the file in which he new data will be sent to

cwd = os.getcwd()
#this the varible 'cwd' to the current working directory
#this is used to assist in the file parth below


full = (cwd + "/" + final)
#the varible ful is set the current working directory plus the file name 
#this var will be used to write the data to the file nam

f = open (full,"a")
#opens the parth of varible 'full'

os.remove(full)
#removes the document if it exists (therefore deleting all content inside)

f = open (full,"a")
#opens file parth again and therefore creates the document

f.write (endProd)
#ites contents of 'endProd' to the document

print ("\n" + "\n" + "The program was a sucess")

print ("\n" + "Please open the 'finalUnicode' document to see the results")
#The above is to onform the user that the program has been compled 

print ("\n" + "\n" + "\n" + "\n" + "\n")
