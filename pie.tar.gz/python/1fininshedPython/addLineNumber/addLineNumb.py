#this.is  a program to.allow you to see all the linue numbers in new society doc
#this is so that you can listen to the document at work and.make mental corrections

#need to create a krun document and save everything in the krun document

import os

f = open("krun.txt","r")

input = f.read()

countLine = input.count("\n")



count = 0

size = len(input)

char = input[0]
charCount = 0
final = ""
######
size-=1
while count < countLine:
 while charCount < size:
  charCount = charCount + 1
  final = final + char
  char = input[charCount]
  if char == "\n":
   count+=1
   countS = str(count)
   final = final + "\n" + "line " + countS + "\n"
 count = countLine + 1


print (final)

finalS = ("finalUnicode.txt")
#this is the name of the file in which he new data will be sent to

cwd = os.getcwd()
#this the varible 'cwd' to the current working directory
#this is used to assist in the file parth below


full = (cwd + "/" + finalS)
#the varible ful is set the current working directory plus the file name 
#this var will be used to write the data to the file nam

f = open (full,"a")
#opens the parth of varible 'full'

os.remove(full)
#removes the document if it exists (therefore deleting all content inside)

f = open (full,"a")
#opens file parth again and therefore creates the document

f.write (final)
#ites contents of 'endProd' to the document
print (final)

###############

print ("\n" + "\n" + "The program was a sucess")

print ("\n" + "Please open the 'finalUnicode' document to see the results")
#The above is to onform the user that the program has been compled 

print ("\n" + "\n" + "\n" + "\n" + "\n")
