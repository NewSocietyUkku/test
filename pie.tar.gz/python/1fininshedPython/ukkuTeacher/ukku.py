#this is a redo.of.the.ptrogram after the.previos one crashed

import random

PS = ["no pronoun","myself","you","you all","him","her","them","we(excluding you)","we (including you)","attaches to the next word"]

word = ["wealth","thanks(before)","thanks(after)","pain","extreme pain","no:stop it","no ans","yes ans","hello for someone you.know","hello.for.someone.you.don't know","record/databe","transaction","money","","taboo","good#bad","addingFocus to the sentence","showingNotTheFocusOf"]


wordForm = ["first word form","second word form"]

suffix = ["because of","prevented/saved","formal/serios","informal/friendly,","-est","not/non","insult","compliment","good","bad","ant","pro","non-habitual","habitual","can.happen","ability to do something"]


tences = ["none","future","pressent","past"]

state = ["none","happenerning","just before","just after","hyperthetical"]

ques = ["no question","normal yes no question","what time","what place","what manner","what reason"]

tip = ["statement please non ins"," statement begging","none","demanding","rhetorical statement","rhetorical statement","quries ques","quires ques","expecting ans demand","expecting anser demand"]

endAll = "j"

while endAll != "k":

 print ("\n\n\n")
 a = (random.choice(wordForm))

 b = (random.choice(suffix))

 c = (random.choice(word))

 d = (random.choice(PS))

 e = (random.choice(word))

 f = (random.choice(PS))

 g = (random.choice(PS))

 h = (random.choice(tences))

 k = (random.choice(ques))

 m = (random.choice(tip))

 i = (random.choice(state))




 print ("word")
 print (c)
 print ("proNounSounds")
 print (d)
 print ("self Description.ProN")
 print (f)
 print ("")
 print ("suffix")
 print (b)
 print ("pronoun attached to suffix")
 print (g)
 print ("")
 print ("second word")
 print (e)
 print ("wordForm")
 print (a)
 print ("tence")
 print (h)
 print ("state")
 print (i)
 print ("")
 print ("quesion word")
 print (k)
 print ("questiin type")
 print (m)




 ans = input("please type in your answer \n")


 endAll = input("type k to end the program \n\n\n")
