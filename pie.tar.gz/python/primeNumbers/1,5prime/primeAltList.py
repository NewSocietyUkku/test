count, end = 0, 50
halfPrime = []
halfSeaPrime = []
halfShadPrime = []
primes = []
shadPrimes = []

halfShadPrime.append(1)

while count < end:
 var=halfShadPrime[count]
 var+=1.5
 count+=1
 halfShadPrime.append(var)
print (halfShadPrime)

halfSeaPrime = halfShadPrime

print (halfSeaPrime)

size = len(halfShadPrime)
print ("monkey")
print (size)
count = 1


while count < size:
#italyFu
 italyCount = 2
 italyFu = halfShadPrime[count]
 while italyCount < end:
  italy = italyFu * italyCount
  franceCount = 1
  while franceCount < size:
    franceFu = halfShadPrime[franceCount]

    if italy == franceFu:
     print ("sucess")
     print (italy)
     print (italyFu)
     print (italyCount)
     halfPrime.append(italy)

    franceCount += 1
  italyCount += 1


 count = count + 1
#cat

for i in halfPrime[:]:
 if (i in halfSeaPrime):
  halfSeaPrime.remove(i)

halfPrime.sort()

halfPrime = list(dict.fromkeys(halfPrime))

count =1

print ("shadow half primes")

print (halfPrime)

for item in halfPrime:
 print (item)
 stCount = str(count)
 print ("			A" + stCount)
 count +=1
print ("half primes")

print (halfSeaPrime)

count = 0

for item in halfSeaPrime:
 print (item)
 stCount = str(count)
 print ("			A" + stCount)
 count +=1


#then program.to.record.actial.primes.and.shadow.primes

#save results.in a text.file with \n used.to.add space between every 5 varibles

#then make.other prohraμto sort.and.compare.the data
