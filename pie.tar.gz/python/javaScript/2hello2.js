//java script provram

console.log('Hello World');

var name = "sandy";

console.log(name)

var x = 6;


console.log(x)
