import array

# Grid dimensions
grid_size = 8
square_size = 50  # Size of each square in pixels
width, height = grid_size * square_size, grid_size * square_size


#need to get the program to get th input from a document in future
# Sample input data (10x10 grid of ones and zeros)
binary_data = [
    "11101111",
    "00010000",
    "11110000",
    "00001111",
    "10101010",
    "01010101",
    "11110000",
    "00001111",
]

# PPM header for binary format
PPMheader = f'P6\n{width} {height}\n255\n'

# Create an empty array to hold image data
image = array.array('B')

# Generate the image pixel data based on the input grid
for row in binary_data:
    for _ in range(square_size):  # Scale row by square size
        for char in row:
            color = [0, 0, 0] if char == '1' else [255, 255, 255]  # Black for 1, White for 0
            for _ in range(square_size):  # Scale column by square size
                image.extend(color)

# Save the image as a PPM file
with open('8by8image.ppm', 'wb') as f:
    f.write(bytearray(PPMheader, 'ascii'))  # Write the PPM header
    image.tofile(f)  # Write the binary image data

print("Image saved as '8by8image.ppm' representing the binary text grid!")
