import os

f = open ("krun","r")

jack = f.readlines()

print (jack)
