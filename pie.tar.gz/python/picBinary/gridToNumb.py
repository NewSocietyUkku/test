# Initialize a 16x16 grid filled with zeros
binary_data = ["0000000000000000" for _ in range(16)]

def update_grid(key):
    """
    Updates the binary grid based on the key pressed.
    Each key corresponds to setting a specific position in the first row to '1'.
    """
    key_map = {
        "a": 0, "b": 1, "c": 2, "d": 3,
        "e": 4, "f": 5, "g": 6, "h": 7,
        "i": 8, "j": 9, "k": 10, "l": 11,
        "m": 12, "n": 13, "o": 14, "p": 15
    }

    if key in key_map:
        pos = key_map[key]
        binary_data[0] = binary_data[0][:pos] + "1" + binary_data[0][pos + 1:]
        print("\nUpdated Grid:")
        for row in binary_data:
            print(row)

print("Type a letter (a-p) to update the grid. Type 'exit' to quit.")

while True:
    key = input("Enter a character: ").strip().lower()
    if key == "exit":
        break
    update_grid(key)
