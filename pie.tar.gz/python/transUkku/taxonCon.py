#might have done it wrong we check spanish rule
sup = "z"
ans = "z"


word = "shshp"
firstAns = "z"
secAns = "z"
thirdAns = "z"
levAns = "z"

res = []

firstAns = input("type 'y' if the taxonmy level is less than two\n")



if firstAns == "y":
 secAns = input ("\n\ntype 'y' if taxonermy lever is equal to zero\n")

 
 if secAns == "y":
  thirdAns = input ("\n\ntype 'a' for archaea\ntype 'b' for bacteria\ntype anything else for eukarya\n\n")

  word = "shshpram-mut"

  if thirdAns == "a":
   word = "shshpram"

  if thirdAns == "b":
    word = "shshpram-mu?t"

if firstAns != "y":
 sup = input ("\n\ntype a for super\ntype b for sub\ntype anything else if no super or sub\n")


 levAns = input("\n\nuoe\ntype a, if second level (Phylum)\ntype b, third level (Class)\ntype c, if fourth level (Order),\ntype d, if OA?=fifth level (Family),\ntype e, if sixth level  (Genus\ntype f, if seventh level (Species)\n")

if secAns != "y":

 ans = input("\n type in the word to be translated\n")

size = len(ans)



ans = ans + "aaaaaaaaaaaaaaaaaaaaa"

charc = ans[0]



if size < 6:
 word = word + "R"

if size == 6:
 word = word + "L"

if size == 7:
 word = word + "R*"

if size == 8:
 word = word + "L*"

if size == 9:
 word = word + "R@"

if size > 9:
 word = word + "L@"

if levAns == "a":
 word = word + "u"
if levAns == "b":
 word = word + "u?"
if levAns == "c":
 word = word + "o"
if levAns == "d":
 word = word + "o?"
if levAns == "e":
 word = word + "e"
if levAns == "f":
 word = word + "e?"
#need to convert.other letters to.sounds two.syllbles
#5 words are shown if no further syllables are added
#there program needs to cooy only the first  5 words


count = 0



#make this all a function


a = 3
b = 3
c = 3
d = 3
e = 3

if firstAns != "y":
 a = 14
 b = 11
 c = 6
 d = 8
 e = 14

if firstAns == "y":
 a = 8
 b = 14
 c = 11
 d = 8
 e = 14

def wordCreate():
 count = 0
 while count < 5:
  charc = ans[count]
  uniChar = [ord(char) for char in charc]
  tester = uniChar[0]
  tester = int(tester)
  if tester < 65:
   print ("warning non character detected Please retype the word to ensure accrucy")
  if tester > 122:
   print ("warning non character detected Please retype the word to ensure accrucy")
  if tester < 97:
   if tester > 99:
    print ("warning non character detected Please retype the word to ensure accrucy")
  tester = tester - 64
  if tester > 30:
   tester = tester -96 + 64
  if count == 0:

   ou = tester/a
   hound = int(ou)
   ou = ou - hound
   ou = ou * a
   ou = round (ou)
   if ou == 0:
    ou = ou + a
   res.append(ou)


  if count == 1:

   ou = tester/b
   hound = int(ou)
   ou = ou - hound
   ou = ou * b
   ou = round (ou)
   if ou == 0:
    ou = ou + b
   res.append(ou)



  if count == 2:

   ou = tester/c
   hound = int(ou)
   ou = ou - hound
   ou = ou * c
   ou = round (ou)
   if ou == 0:
    ou = ou + c
   res.append(ou)



  if count == 3:

   ou = tester/d
   hound = int(ou)
   ou = ou - hound
   ou = ou * d
   ou = round (ou)
   if ou == 0:
    ou = ou + d
   res.append(ou)




  if count == 4:

   ou = tester/e
   hound = int(ou)
   ou = ou - hound
   ou = ou * e
   ou = round (ou)
   if ou == 0:
    ou = ou + e
   res.append(ou)

  water = res[count]

  water = water - 1

  res[count] = water

  count = count + 1

wordCreate()

stagEnd = ["m","ms","msh","nt","n","ns","nsh","nts","ntsh","t","ts","tsh","s","sh"]

stagStart = ["m","sm","shm","n","sn","shn","t","st","sht","s","sh"]

hiddenSound = ["R","L","R*","L*","R@","L@"]

bridge = ["u","u?","o","o?","e","e?","a","a?"]

if firstAns != "y":
 krun = res[0]
 ext = stagEnd[krun]
 word = word + ext + "-"
 krun = res[1]
 ext = stagStart[krun]
 word = word + ext
 krun = res[2]
 ext = hiddenSound[krun]
 word = word + ext
 krun = res[3]
 ext = bridge[krun]
 word = word + ext
 krun = res[4]
 ext = stagEnd[krun]
 word = word + ext
  

if firstAns == "y":
 krun = res[0]
 ext = bridge[krun]
 word = word + ext
 
 krun = res[1]
 ext = stagEnd[krun]
 word = word + ext + "-"

 krun = res[2]

 ext = stagStart[krun]
 word = word + ext

 krun = res[3]
 ext = bridge[krun]
 word = word + ext
 krun = res[4]
 ext = stagEnd[krun]
 word = word + ext



if sup == "a":
 word = word + "/shshp/"

if sup == "b":
 word = word + "/shshp/"
#a?

dog = len(word)



buck = dog - 1

cat = word[buck]

if cat == "/":
	word = word[:-1]
	ans = input("\n type in the word to be translated\n")


	ans = ans + "aaaaaaaaaaaaaaaaaaaaa"

	charc = ans[0]

	size = len(ans)

	if size < 6:
	 word = word + "R"

	if size == 6:
	 word = word + "L"

	if size == 7:
	 word = word + "R*"

	if size == 8:
	 word = word + "L*"

	if size == 9:
	 word = word + "R@"

	if size > 9:
	 word = word + "L@"

	if sup == "a":

	 word = word + "a"

	if sup == "b":
	 word = word + "a?"
	a = 14
	b = 11
	c = 6
	d = 8
	e = 14
	res.clear()
	wordCreate()

stagEnd = ["m","ms","msh","nt","n","ns","nsh","nts","ntsh","t","ts","tsh","s","sh"]

stagStart = ["m","sm","shm","n","sn","shn","t","st","sht","s","sh"]

hiddenSound = ["R","L","R*","L*","R@","L@"]

bridge = ["u","u?","o","o?","e","e?","a","a?"]

if cat == "/":
 krun = res[0]
 ext = stagEnd[krun]
 word = word + ext + "-"
 krun = res[1]
 ext = stagStart[krun]
 word = word + ext
 krun = res[2]
 ext = hiddenSound[krun]
 word = word + ext
 krun = res[3]
 ext = bridge[krun]
 word = word + ext
 krun = res[4]
 ext = stagEnd[krun]
 word = word + ext
  
if secAns == "y":
 word = "shshpram-mut"

 if thirdAns == "a":
  word = "shshpram"

 if thirdAns == "b":
  word = "shshpram-mu?t"



print (word)
print (res)
