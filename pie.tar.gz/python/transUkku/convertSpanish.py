##last thing to figure out why the.program.crashes if prlgram is.to.big

##basically.why is.11 appearing in.the.arrays

#double check.if.list.numbs are acuret.large.lists


 
#try to find the.reason that it keeps  givimg diffrent results for large.words, see where it seoerates



####Alt  + { remove tabs on selected
####Alt  + } add tabs on selected

res = []

firstAns = input ("\nIf you describe something with the word does that description make it \ntype a if it it makes it tangerble\nb if it makes it non tangable\ntype anything else if it doesnt change the tangerbility of the word\n\n\n")



#h needs to be removed

word = "b"


if firstAns == "a":
 word = "sb"


if firstAns == "b":
 word = "shb"

ans = input("\n type in the word to be translated\n")



ans = ans.replace(" ","")

ans = ans.replace("h","")

ans = ans.replace("H","")



size = len(ans)


print (size)
print ("size")

ans = ans + "aaaaaaaaaaaaaaaaaaaaa"



charc = ans[0]

syll = size
log = size


if size == 1:
 word = word + "L"

if size == 2:
 word = word + "R"


if size > 2:
	syll = syll - 2
	log = log - 2

	log = log/4
	syll = syll/4

	log = int(log)

	SLUG = log - syll
	SLUG = SLUG + 1
	if SLUG == 1:
 		word = word + "R"



	if SLUG == 0.75:
		word = word + "L"
	#tra
	if SLUG == 0.50:
		word = word + "R*"
	#tr
	if SLUG == 0.25:
		word = word + "L*"
	#t




count = 0

a = 8
b = 14


c = 11
d = 6
e = 8
f = 14

duckSize=size


if duckSize < 6:
 duckSize = 6

def wordCreate():
 count = 0
 while count < duckSize:


  charc = ans[count]
  uniChar = [ord(char) for char in charc]
  tester = uniChar[0]
  tester = int(tester)


  if tester == 104:
   print ("warning 'h/H' character detected.This is not allowed. Please retype the word and remove the H\n") 
  if tester == 72:
   print ("warning 'h/H' character detected.This is not allowed. Please retype the word and remove the H\n") 


  if tester < 65:
   print ("warning non character detected Please retype the word to ensure accrucy")
  if tester > 122:
   print ("warning non character detected Please retype the word to ensure accrucy")
  if tester < 97:
   if tester > 99:
    print ("warning non character detected Please retype the word to ensure accrucy")
  tester = tester - 64
  if tester > 30:
   tester = tester -96 + 64
  if count == 0:

   ou = tester/a
   hound = int(ou)
   ou = ou - hound
   ou = ou * a
   ou = round (ou)
   if ou == 0:
    ou = ou + a
   res.append(ou)


  if count == 1:

   ou = tester/b
   hound = int(ou)
   ou = ou - hound
   ou = ou * b
   ou = round (ou)
   if ou == 0:
    ou = ou + b
   res.append(ou)



  if count == 2:

   ou = tester/c
   hound = int(ou)
   ou = ou - hound
   ou = ou * c
   ou = round (ou)
   if ou == 0:
    ou = ou + c
   res.append(ou)



  if count == 3:

   ou = tester/d
   hound = int(ou)
   ou = ou - hound
   ou = ou * d
   ou = round (ou)
   if ou == 0:
    ou = ou + d
   res.append(ou)




  if count == 4:

   ou = tester/e
   hound = int(ou)
   ou = ou - hound
   ou = ou * e
   ou = round (ou)
   if ou == 0:
    ou = ou + e
   res.append(ou)





  if count == 5:

   ou = tester/f
   hound = int(ou)
   ou = ou - hound
   ou = ou * f
   ou = round (ou)
   if ou == 0:
    ou = ou + f
   res.append(ou)



######


  za = 2
  countZ = count + 20
  while za < countZ:
	  za = za + 4
	  if count == za:

	   ou = tester/c
	   hound = int(ou)
	   ou = ou - hound
	   ou = ou * c
	   ou = round (ou)
	   if ou == 0:
	    ou = ou + c
	   res.append(ou)



  za = 3
  countZ = count + 20
  while za < countZ:
	  za = za + 4


	  if count == za:

	   ou = tester/d
	   hound = int(ou)
	   ou = ou - hound
	   ou = ou * d
	   ou = round (ou)
	   if ou == 0:
	    ou = ou + d
	   res.append(ou)



  za = 4
  countZ = count + 20
  while za < countZ:
	  za = za + 4

	  if count == za:

	   ou = tester/e
	   hound = int(ou)
	   ou = ou - hound
	   ou = ou * e
	   ou = round (ou)
	   if ou == 0:
	    ou = ou + e
	   res.append(ou)



  za = 9
  countZ = count + 20
  while za < countZ:
	  za = za + 4


	  if count == za:

	   ou = tester/f
	   hound = int(ou)
	   ou = ou - hound
	   ou = ou * f
	   ou = round (ou)
	   if ou == 0:
	    ou = ou + f
	   res.append(ou)

  count = count + 1



wordCreate()

hat = len(res)


print (res)

print (hat)

print ("list.lenth")


waterC = 0
river = len(res)
while waterC < river:
 water = res[waterC]
 water = water - 1
 res[waterC] = water
 
 waterC = waterC + 1


stagEnd = ["m","ms","msh","nt","n","ns","nsh","nts","ntsh","t","ts","tsh","s","sh"]

stagStart = ["m","sm","shm","n","sn","shn","t","st","sht","s","sh"]

hiddenSound = ["R","L","R*","L*","R@","L@"]

bridge = ["u","u?","o","o?","e","e?","a","a?"]

krun = res[0]
ext = bridge[krun]
word = word + ext
 
krun = res[1]
ext = stagEnd[krun]
word = word + ext + "-"

krun = res[2]

ext = stagStart[krun]
word = word + ext

krun = res[3]
ext = hiddenSound [krun]
word = word + ext



krun = res[4]
ext = bridge[krun]
word = word + ext

krun = res[5]
ext = stagEnd[krun]
word = word + ext

evil = 0

art = len(res)

if art > 6:
 paint = 10
 evil = evil + 1
 while paint < art:
  evil = evil + 1
  paint = paint + 4 





art = art - 1
small = size-2

talk = word

if size < 3:
 word = word[:-5]


art += 1




read = 0

scream = 6

sign = 1

while scream < art:

	speak = res [scream]



	if read == 0:
	 sign+=1
	 frog = sign/2
	 mold = int(frog)
	 worm = frog - mold
	 
	 if worm ==0:
	  ham = "/"

	 if worm > 0:
	  ham = "-"
	 ext = stagStart[speak]
	 talk = talk + ham  + ext
	 print (sign)


	if read == 1:




	 ext = hiddenSound [speak]
	 talk = talk + ext


	if read == 2:



	 ext = bridge[speak]
	 talk = talk + ext



	if read == 3:


	 ext = stagEnd[speak]
	 talk = talk + ext

#	speak = str(speak)

#	talk = talk + speak


	scream += 1
	read += 1

	if read > 3:
	 read = 0




size = len(word)

if size < 7:
 talk = talk[:-5]


 ext = hiddenSound [0]
 talk = talk + ext


 ext = bridge[0]
 talk = talk + ext
 ext = stagEnd[0]
 talk = talk + ext


if read == 2:
 ext = bridge[0]
 talk = talk + ext
 ext = stagEnd[0]
 talk = talk + ext


if read == 3:
 ext = stagEnd[0]
 talk = talk + ext




read = str(read)

talk = talk + read

monkey = len(word)

if monkey < 7:
 talk = word

print (talk)

