####Alt  + { remove tabs on selected
####Alt  + } add tabs on selected

res = []

firstAns = input ("\nPlease list which of the following the word is \ntype a if you refearing to the state/goverment\ntype b if it you refearig to the land controlled by tbe goverment\ntyoe c for land/location\ntype anything else if it is a commno name\n\n\n")

word = "shp"


if firstAns == "a":
 word = "ssg"


if firstAns == "b":
 word = "shg"

if firstAns == "c":
 word = "shshg"


ans = input("\n type in the word to be translated\n")

size = len(ans)

ans = ans + "aaaaaaaaaaaaaaaaaaaaa"



charc = ans[0]



if size < 7:
 word = word + "R"

if size == 7:
 word = word + "L"

if size == 8:
 word = word + "R*"

if size == 9:
 word = word + "L*"

if size == 10:
 word = word + "R@"

if size > 11:
 word = word + "L@"

count = 0

a = 8
b = 14
c = 11
d = 6
e = 8
f = 14



def wordCreate():
 count = 0
 while count < 6:
  charc = ans[count]
  uniChar = [ord(char) for char in charc]
  tester = uniChar[0]
  tester = int(tester)
  if tester < 65:
   print ("warning non character detected Please retype the word to ensure accrucy")
  if tester > 122:
   print ("warning non character detected Please retype the word to ensure accrucy")
  if tester < 97:
   if tester > 99:
    print ("warning non character detected Please retype the word to ensure accrucy")
  tester = tester - 64
  if tester > 30:
   tester = tester -96 + 64
  if count == 0:

   ou = tester/a
   hound = int(ou)
   ou = ou - hound
   ou = ou * a
   ou = round (ou)
   if ou == 0:
    ou = ou + a
   res.append(ou)


  if count == 1:

   ou = tester/b
   hound = int(ou)
   ou = ou - hound
   ou = ou * b
   ou = round (ou)
   if ou == 0:
    ou = ou + b
   res.append(ou)



  if count == 2:

   ou = tester/c
   hound = int(ou)
   ou = ou - hound
   ou = ou * c
   ou = round (ou)
   if ou == 0:
    ou = ou + c
   res.append(ou)



  if count == 3:

   ou = tester/d
   hound = int(ou)
   ou = ou - hound
   ou = ou * d
   ou = round (ou)
   if ou == 0:
    ou = ou + d
   res.append(ou)




  if count == 4:

   ou = tester/e
   hound = int(ou)
   ou = ou - hound
   ou = ou * e
   ou = round (ou)
   if ou == 0:
    ou = ou + e
   res.append(ou)





  if count == 5:

   ou = tester/f
   hound = int(ou)
   ou = ou - hound
   ou = ou * f
   ou = round (ou)
   if ou == 0:
    ou = ou + f
   res.append(ou)


  water = res[count]

  water = water - 1

  res[count] = water

  count = count + 1

wordCreate()

stagEnd = ["m","ms","msh","nt","n","ns","nsh","nts","ntsh","t","ts","tsh","s","sh"]

stagStart = ["m","sm","shm","n","sn","shn","t","st","sht","s","sh"]

hiddenSound = ["R","L","R*","L*","R@","L@"]

bridge = ["u","u?","o","o?","e","e?","a","a?"]

krun = res[0]
ext = bridge[krun]
word = word + ext
 
krun = res[1]
ext = stagEnd[krun]
word = word + ext + "-"

krun = res[2]

ext = stagStart[krun]
word = word + ext

krun = res[3]
ext = hiddenSound [krun]
word = word + ext



krun = res[4]
ext = bridge[krun]
word = word + ext

krun = res[5]
ext = stagEnd[krun]
word = word + ext






print (word)
print (res)

print ("Other form of word")
grey = len(word)
mons = 1
blue = ""
monsCount = 1
while mons == 1:
	heart = word[monsCount]
	heart = str(heart)
	if heart == "u":
	 pink = str(monsCount)
	 blue = blue + pink 
	if heart == "o":
	 pink = str(monsCount)
	 blue = blue + pink 
	if heart == "e":
	 pink = str(monsCount)
	 blue = blue + pink 
	if heart == "a":
	 pink = str(monsCount)
	 blue = blue + pink 

	if heart == "-":
	 mons = 0
	 blood = monsCount
	monsCount = monsCount + 1
heart = word[monsCount]
while monsCount < grey:
 heart = heart + word[monsCount]

 monsCount = monsCount + 1

leg = blue[0]

leg = int(leg)

leg = leg - 1

bone=+ = ""
while leg > 0:
 bone = bone + word[leg]
 leg = leg - 1

print (blue)
print (bone)
print (heart)


heart = heart + " a"

def brain(s):
 words = s.split()
 return ' '.join(words[:1])

heart = brain(heart)

heart = heart[1:]

heart = heart + "-" + bone


print ("go")
print (heart)

